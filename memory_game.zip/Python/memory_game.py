import tkinter as tk
import random
from tkinter import messagebox
import time
import os
import winsound  # For sound effects on Windows


# Play sound (Beep on Windows)
def play_sound(frequency=440, duration=200):
    try:
        winsound.Beep(frequency, duration)
    except:
        pass


# Memory Game Class
class MemoryGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Memory Matching Game with Restart")
        self.root.geometry("500x650")
        self.root.resizable(False, False)

        self.best_moves = None
        self.best_time = None
        self.load_best_scores()

        self.setup_game()

    def setup_game(self):
        self.cards = list(range(1, 9)) * 2
        random.shuffle(self.cards)
        self.buttons = []
        self.flipped = []
        self.moves = 0
        self.start_time = time.time()

        for widget in self.root.winfo_children():
            widget.destroy()

        self.create_widgets()

    def create_widgets(self):
        self.info_frame = tk.Frame(self.root)
        self.info_frame.pack(pady=10)

        self.moves_label = tk.Label(self.info_frame, text="Moves: 0", font=("Arial", 14))
        self.moves_label.pack(side="left", padx=10)

        self.timer_label = tk.Label(self.info_frame, text="Time: 0s", font=("Arial", 14))
        self.timer_label.pack(side="left", padx=10)

        self.best_label = tk.Label(self.info_frame, text=self.get_best_score_text(), font=("Arial", 14))
        self.best_label.pack(side="left", padx=10)

        self.restart_button = tk.Button(self.root, text="Restart Game", font=("Arial", 12, "bold"),
                                        bg="orange", command=self.restart_game)
        self.restart_button.pack(pady=10)

        self.board_frame = tk.Frame(self.root)
        self.board_frame.pack()

        for i in range(16):
            btn = tk.Button(self.board_frame, text="", width=8, height=4,
                            bg="lightgray", font=("Arial", 18, "bold"),
                            command=lambda i=i: self.flip_card(i))
            btn.grid(row=i // 4, column=i % 4, padx=5, pady=5)
            self.buttons.append(btn)

        self.update_timer()

    def get_best_score_text(self):
        if self.best_moves is not None and self.best_time is not None:
            return f"Best: {self.best_moves} moves, {self.best_time}s"
        else:
            return "Best: N/A"

    def update_timer(self):
        elapsed = int(time.time() - self.start_time)
        self.timer_label.config(text=f"Time: {elapsed}s")
        self.root.after(1000, self.update_timer)

    def flip_card(self, index):
        if len(self.flipped) < 2 and self.buttons[index]['text'] == "":
            self.buttons[index]['text'] = str(self.cards[index])
            self.buttons[index]['bg'] = "lightblue"
            play_sound(500, 150)
            self.flipped.append(index)

            if len(self.flipped) == 2:
                self.root.after(700, self.check_match)
                self.moves += 1
                self.moves_label.config(text=f"Moves: {self.moves}")

    def check_match(self):
        first, second = self.flipped
        if self.cards[first] == self.cards[second]:
            self.buttons[first]['state'] = 'disabled'
            self.buttons[second]['state'] = 'disabled'
            self.buttons[first]['bg'] = "lightgreen"
            self.buttons[second]['bg'] = "lightgreen"
            play_sound(700, 200)
        else:
            self.buttons[first]['text'] = ""
            self.buttons[second]['text'] = ""
            self.buttons[first]['bg'] = "lightgray"
            self.buttons[second]['bg'] = "lightgray"
            play_sound(300, 150)

        self.flipped.clear()
        self.check_win()

    def check_win(self):
        if all(button['state'] == 'disabled' for button in self.buttons):
            elapsed_time = int(time.time() - self.start_time)
            play_sound(1000, 500)
            self.update_best_scores(elapsed_time)

            messagebox.showinfo("You Win!",
                                f"Congratulations!\nMoves: {self.moves}\nTime: {elapsed_time} seconds\n\n"
                                f"Best: {self.best_moves} moves, {self.best_time} seconds")

    def restart_game(self):
        self.setup_game()

    def load_best_scores(self):
        if os.path.exists("high_scores.txt"):
            with open("high_scores.txt", "r") as file:
                lines = file.readlines()
                if len(lines) >= 2:
                    self.best_moves = int(lines[0].strip())
                    self.best_time = int(lines[1].strip())

    def update_best_scores(self, elapsed_time):
        if (self.best_moves is None) or (self.moves < self.best_moves) or (self.moves == self.best_moves and elapsed_time < self.best_time):
            self.best_moves = self.moves
            self.best_time = elapsed_time
            with open("high_scores.txt", "w") as file:
                file.write(f"{self.best_moves}\n{self.best_time}\n")
            self.best_label.config(text=self.get_best_score_text())


if __name__ == "__main__":
    root = tk.Tk()
    game = MemoryGame(root)
    root.mainloop()
